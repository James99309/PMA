#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
用户模块测试脚本

此脚本用于测试用户模块的基本功能是否正常。
"""

import requests
import logging
import json
import sys

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('user_module_test.log')
    ]
)
logger = logging.getLogger(__name__)

def test_user_list(base_url, token):
    """测试用户列表功能"""
    url = f"{base_url}/user/list"
    headers = {"Authorization": f"Bearer {token}"}
    
    try:
        logger.info(f"测试用户列表页面: {url}")
        response = requests.get(url, headers=headers)
        
        if response.status_code == 200:
            logger.info("用户列表页面访问成功")
            return True
        else:
            logger.error(f"用户列表页面访问失败: {response.status_code}")
            return False
    except Exception as e:
        logger.error(f"测试用户列表功能时出错: {str(e)}")
        return False

def test_user_api(base_url, token):
    """测试用户API功能"""
    url = f"{base_url}/api/v1/users"
    headers = {"Authorization": f"Bearer {token}"}
    
    try:
        logger.info(f"测试用户API: {url}")
        response = requests.get(url, headers=headers)
        
        try:
            data = response.json()
            if response.status_code == 200 and data.get('success'):
                logger.info("用户API访问成功")
                return True
            else:
                error_msg = data.get('message', '未知错误')
                logger.error(f"用户API访问失败: {error_msg}")
                return False
        except json.JSONDecodeError as e:
            logger.error(f"解析API响应失败: {str(e)}")
            return False
    except Exception as e:
        logger.error(f"测试用户API功能时出错: {str(e)}")
        return False

def main():
    """主函数"""
    if len(sys.argv) < 3:
        print("用法: python test_user_module.py <base_url> <token>")
        sys.exit(1)
        
    base_url = sys.argv[1]
    token = sys.argv[2]
    
    # 运行测试
    tests = [
        ("用户列表功能", test_user_list(base_url, token)),
        ("用户API功能", test_user_api(base_url, token))
    ]
    
    # 输出测试结果
    print("\n测试结果:")
    all_passed = True
    for name, result in tests:
        status = "通过" if result else "失败"
        print(f"{name}: {status}")
        if not result:
            all_passed = False
    
    # 返回测试结果
    return 0 if all_passed else 1

if __name__ == "__main__":
    sys.exit(main())
