# 用户模块同步更新包

## 更新内容
此部署包包含用户模块的最新代码，主要修复以下问题：
1. 添加了JSON解析的异常处理
2. 确保用户模块的权限定义一致
3. 修复用户模块在render环境中的问题

## 文件列表
- app/views/user.py
- app/models/user.py
- app/permissions.py
- app/utils/permissions.py
- app/templates/user/list.html
- app/templates/user/edit.html
- app/templates/user/permissions.html
- app/templates/user/affiliations.html

## 更新时间
2025-05-04 08:45:16
